module.exports = [{ //https://discord.com/api/webhooks/830868134210306079/oE2BqaooBJ_PAb3A3NgLcZExRQK4-kEmJoL1LadDeZ-HlxSOVKqro9WmAe8BSHsfXt5l
	channel: "794570132470366208",
	code: `$setServerVar[logswebhookid;830868134210306079]
	$setServerVar[logswebhooktoken;oE2BqaooBJ_PAb3A3NgLcZExRQK4-kEmJoL1LadDeZ-HlxSOVKqro9WmAe8BSHsfXt5l]
	
	$title[Bot Added]
	$description[
	$addField[Invite Link;$getServerInvite;no]
	$addField[Name;$serverName;no]
	$addField[Owner;$userTag[$ownerID];no]
	$addField[Members Count;$membersCount;no]]
	$color[BLACK]
	`,
	type: "botJoinCommand"
}, {
	channel: "794570415023849473",
	code: "Bot removed from $serverName",
	type: "botLeaveCommand"
}];