module.exports = [{
	name: "decode",
	code: `
	$if[$message[2]==base64]
	
	$elseif[$message[2]==binary]
	
	$endelseif
	$endif
  
   $onlyIf[$isBot[$authorID]==false;] `
}]