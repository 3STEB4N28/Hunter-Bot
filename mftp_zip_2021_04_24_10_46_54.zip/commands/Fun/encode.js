module.exports = [{
	name: "encode",
	code: `$if[$message[1]==base64]
	
	$reply[$messageID;{title:Base64 Encode}
	{description:$jsonRequest[https://api.3steb4n28.xyz/api/v1/base64?type=encode&text=$messageSlice[1]&authorization=hbb;message;{execute:apie}]}
	{color:BLACK};no]
	
	$elseif[$message[1]==binary]
	
	$reply[$messageID;{title:Binary Encode}
	{description:$jsonRequest[https://api.3steb4n28.xyz/api/v1/binary?type=encode&text=$messageSlice[1]&authorization=hbb;message;{execute:apie}]}
	{color:BLACK};no]
	
	$endelseif
	$endif
  
  $onlyIf[$isBot[$authorID]==false;] `
}]