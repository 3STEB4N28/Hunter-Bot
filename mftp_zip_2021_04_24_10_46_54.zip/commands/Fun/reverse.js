module.exports = {
	name: "reverse",
	code: `
	$reply[$messageID;{title:Reverse Text}
	{description:$jsonRequest[https://api.3steb4n28.xyz/api/v1/reverse?text=$message;message;{execute:apie}]}
	{color:BLACK};no]
	
	$argsCheck[>1;Please add some text to reverse!]
  
   $onlyIf[$isBot[$authorID]==false;] `
}