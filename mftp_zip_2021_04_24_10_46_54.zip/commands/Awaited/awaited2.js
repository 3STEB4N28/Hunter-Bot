module.exports = [{
	name: "test",
	code: `$gen`,
	type: "awaitedCommand"
}]